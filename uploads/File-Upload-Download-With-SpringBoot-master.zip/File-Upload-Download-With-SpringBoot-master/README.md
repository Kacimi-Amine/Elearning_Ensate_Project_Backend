# File-Upload-Download-With-SpringBoot (Single Microservice)
 File Upload | Download | Rendering to local file system as well as Database
 
 * [Part - 1 Single File upload download to filesystem](https://youtu.be/LUq4UtsGcyU)
 
 * [Part - 2 Multiple File upload download to filesystem](https://youtu.be/l0HsJJzCTj4)
 
 * [Part - 3 File upload download to database(mysql)](https://youtu.be/8YDeBkNidmg)
 
 * [Part - 4(Bonus) - Integration test](https://youtu.be/FzlfQErXLmo)
 
 
## Let's use the above microservice 

Below is the future plan that can be looked into. As soon as i compelte video, will update the link

* [Part - 5 Java Client to call the file-upload service](https://youtu.be/t0Xy_Y9w6ik)

* [Part - 6 Angular Application to call the file-upload service and upload/download file] - TODO

* [Part - 7 React Application to call the file-upload service and upload/download file] - TODO
