CREATE TABLE green.file_document (
    id long,
    fileName varchar(30),
    docFile longblob
);

select * from green.file_document;