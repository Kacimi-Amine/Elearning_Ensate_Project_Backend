package com.clientservice.clientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
